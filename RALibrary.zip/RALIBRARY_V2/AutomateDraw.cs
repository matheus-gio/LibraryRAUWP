﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;

namespace RALIBRARY_V2
{
    public class AutomateDraw
    {
        CanvasDraw canvasDraw;
        public AutomateDraw(CanvasDraw canvasDraw)
        {
            this.canvasDraw = canvasDraw;
        }
        bool text = false, line = false, square = false, circle = false, rectangle = false;
        public bool Text
        {
            get
            {
                return this.text;
            }
            set
            {
                square = false;
                line = false;
                circle = false;
                rectangle = false;
                this.text = value;
            }
        }
        public bool Line
        {
            get
            {
                return this.line;
            }
            set
            {
                square = false;
                this.line = value;
                circle = false;
                rectangle = false;
                text = false;
            }
        }

        public bool Square
        {
            get
            {
                return this.square;
            }
            set
            {
                this.square = value;
                line = false;
                circle = false;
                rectangle = false;
                text = false;
            }
        }

        public bool Circle
        {
            get
            {
                return this.circle;
            }
            set
            {
                square = false;
                line = false;
                this.circle = value;
                rectangle = false;
                text = false;
            }
        }
        public bool Rectangle
        {
            get
            {
                return this.rectangle;
            }
            set
            {
                square = false;
                line = false;
                circle = false;
                this.rectangle = value;
                text = false;
            }
        }

        public void SetArrowCursor()
        {
            Window.Current.CoreWindow.PointerCursor = new Windows.UI.Core.CoreCursor(Windows.UI.Core.CoreCursorType.Arrow, 0);
        }
        public void SetNoneCursor()
        {
            Window.Current.CoreWindow.PointerCursor = null;
        }
        public async void CreateElementPointerPressed(Canvas canvas,double size, Color color, UIElement ui, PointerRoutedEventArgs e)
        {
            if (canvasDraw.LeftPressed(e, ui))
            {
                if (Line) canvasDraw.CreateLine(canvas, size, e, color);
                if (Square) canvasDraw.CreateSquare(canvas, e, size, color);
                if (Circle) canvasDraw.CreateCircle(canvas, e, size, color);
                if (Rectangle) canvasDraw.Create_Rectangle(canvas, e, color);
                if (Text)
                {
                    Tuple<double, double> position = canvasDraw.GetPositionPoiter(canvas, e);
                    MessageControl message = new MessageControl();
                    String message_txt = await message.InputTextDialogAsync(canvasDraw, "Escreva o texto a ser adicionado");
                    canvasDraw.CreateText(message_txt, canvas, size, e, color, position.Item1, position.Item2);
                }
            }
            else
            {
                canvasDraw.DisableClick();
                SetArrowCursor();
            }
        }

        public void Cursors(Canvas canvas, double size, PointerRoutedEventArgs e, Color color)
        {
            if (Line) canvasDraw.Cursor_Line(canvas, size, e, color);
            if (Square) canvasDraw.Cursor_Square(canvas, size, e, color);
            if (Circle) canvasDraw.Cursor_Circle(canvas, size, e, color);
            if (circle || square)
            {
                SetNoneCursor();
            }
            else
            {
                SetArrowCursor();
            }
        }

        public void ClearCanvas(Canvas canvas)
        {
            square = false;
            line = false;
            circle = false;
            rectangle = false;
            text = false;
            canvas.Children.Clear();
        }
        public void Undo_Draw(Canvas canvas)
        {
            if (canvas.Children.Count > 0) canvas.Children.RemoveAt(canvas.Children.Count - 1);
        }
    }
}
