﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel.Core;
using Windows.Graphics.Imaging;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.Storage.Streams;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media.Imaging;

namespace RALIBRARY_V2
{
    public class ImageControl
    {
        private Image img_background = null;

        public void BackgroundImageDraw(Canvas canvas, Image img_draw, double opacity)
        {
            img_draw.Opacity = opacity;
            if (img_background != null)
            {
                canvas.Children.Remove(img_background);
            }
            var bounds = Window.Current.Bounds;
            double height = bounds.Height;
            double width = bounds.Width;
            img_draw.Width = width;
            img_draw.Height = height;
            Canvas.SetLeft(img_draw, 0);
            Canvas.SetTop(img_draw, 0);
            canvas.Children.Add(img_draw);

            img_background = img_draw;
        }


        public void BackgroundImageDraw(Canvas canvas)
        {
            canvas.Children.Remove(img_background);
            img_background = null;
        }



        public async Task<Image> GetImageFilePicker()
        {
            FileOpenPicker openPicker = new FileOpenPicker();
            openPicker.ViewMode = PickerViewMode.Thumbnail;
            openPicker.SuggestedStartLocation = PickerLocationId.PicturesLibrary;
            openPicker.FileTypeFilter.Add(".jpg");
            openPicker.FileTypeFilter.Add(".jpeg");
            openPicker.FileTypeFilter.Add(".png");

            StorageFile file = await openPicker.PickSingleFileAsync();

            if (file != null)
            {
                // caso tenha encontrado algum arquivo
                var stream = await file.OpenAsync(Windows.Storage.FileAccessMode.Read);
                var image = new BitmapImage();
                image.SetSource(stream);
                Image img = new Image();
                img.Source = image;
                return img;
            }
            else
            {
                return null;
            }

        }

        public async Task<List<Image>> GetDiskImagesAsync(StorageFolder picturesFolder)
        {
            List<Image> imagens = new List<Image>();
            /*await CoreApplication.MainView.CoreWindow.Dispatcher.RunAsync(
            CoreDispatcherPriority.Normal, async () => {
                
            });*/
            IReadOnlyList<IStorageItem> itemsList = await picturesFolder.GetFilesAsync();
            foreach (var item in itemsList)
            {
                await picturesFolder.TryGetItemAsync(item.Name);
                if (item.Path.Contains(".jpg") || item.Path.Contains(".png") || item.Path.Contains(".jpeg"))
                {
                    try
                    {
                        var uri = new System.Uri(item.Path);
                        var converted = uri.AbsoluteUri;
                        StorageFile file = await picturesFolder.GetFileAsync(item.Name);
                        BitmapImage bitmapImage = new BitmapImage();
                        FileRandomAccessStream stream = (FileRandomAccessStream)await file.OpenAsync(FileAccessMode.Read);
                        bitmapImage.SetSource(stream);
                        Image image = new Image();
                        image.Name = item.Name;

                        image.Source = bitmapImage;
                        imagens.Add(image);

                    }
                    catch (Exception e)
                    {
                        Debug.WriteLine(e);
                    }

                }
            }
            return imagens;
        }

        public async Task AddImgtoCanvasAsync(Canvas canvas, Image image_)
        {
            await CoreApplication.MainView.CoreWindow.Dispatcher.RunAsync(
            CoreDispatcherPriority.Normal, () =>
            {
                canvas.Children.Clear();
                var bounds = Window.Current.Bounds;
                double height = bounds.Height;
                double width = bounds.Width;

                Image image = new Image()
                {
                    Height = height,
                    Width = width,
                    Source = image_.Source
                };
                Canvas.SetLeft(image, 0);
                Canvas.SetTop(image, 0);
                canvas.Children.Add(image);
            });
        }


        public void GetImagesWebAsync(String url, List<String> list_nomes, StorageFolder folder)
    {
        foreach (String art in list_nomes)
        {
            DownloaImageDisk(url, art, folder);
        }
    }
    public async void DownloaImageDisk(string url, string path, StorageFolder folder)
    {

        await CoreApplication.MainView.CoreWindow.Dispatcher.RunAsync(
            CoreDispatcherPriority.Normal, async () =>
            {
                System.Net.HttpStatusCode result = default(System.Net.HttpStatusCode);
                var request = HttpWebRequest.Create(url + path);
                request.Method = "HEAD";

                using (var response = await request.GetResponseAsync() as HttpWebResponse)
                {
                    if (response != null)
                    {
                        result = response.StatusCode;
                        if (result == System.Net.HttpStatusCode.OK)
                        {
                            try
                            {
                                StorageFolder temp;
                                try
                                {
                                    temp = await folder.GetFolderAsync("TEMP");
                                }
                                catch
                                {
                                     temp = await folder.CreateFolderAsync("TEMP");
                                }
                                StorageFile file = await temp.CreateFileAsync(path, CreationCollisionOption.ReplaceExisting);

                                HttpClient client = new HttpClient(); // Create HttpClient
                                byte[] buffer = await client.GetByteArrayAsync(url+path); // Download file
                                using (Stream stream = await file.OpenStreamForWriteAsync())
                                    stream.Write(buffer, 0, buffer.Length); // Save
                                await file.MoveAsync(folder,path, NameCollisionOption.ReplaceExisting);
                            }
                            catch { }
                        }
                    }
                }
            });
    }


public async Task saveImageAsync(Canvas canvas, StorageFolder folder, string nome)
        {
            StorageFile file;

            file = await folder.CreateFileAsync(nome, CreationCollisionOption.ReplaceExisting);
            RenderTargetBitmap renderTargetBitmap = new RenderTargetBitmap();
            await renderTargetBitmap.RenderAsync(canvas);
            var pixels = await renderTargetBitmap.GetPixelsAsync();

            using (IRandomAccessStream stream = await file.OpenAsync(FileAccessMode.ReadWrite))
            {
                var encoder = await
                    BitmapEncoder.CreateAsync(BitmapEncoder.JpegEncoderId, stream);
                byte[] bytes = pixels.ToArray();
                encoder.SetPixelData(BitmapPixelFormat.Bgra8,
                                        BitmapAlphaMode.Ignore,
                                        (uint)canvas.ActualWidth, (uint)canvas.ActualHeight,
                                        96, 96, bytes);

                await encoder.FlushAsync();
            }
        }
    }
}
