﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;

namespace RALIBRARY_V2
{
    public class MessageControl
    {
        public async Task<String> InputTextDialogAsync(CanvasDraw canvasdraw, string title)
        {
            TextBox inputTextBox = new TextBox();
            inputTextBox.AcceptsReturn = false;
            inputTextBox.Height = 32;
            ContentDialog dialog = new ContentDialog();
            dialog.Content = inputTextBox;
            dialog.Title = title;
            dialog.IsSecondaryButtonEnabled = true;
            dialog.PrimaryButtonText = "Ok";
            dialog.SecondaryButtonText = "Cancelar";
            ContentDialogResult dialog_result = await dialog.ShowAsync();
            if (dialog_result == ContentDialogResult.Secondary)
            {
                return String.Empty;
            }
            if (dialog_result == ContentDialogResult.Primary)
            {
                return inputTextBox.Text;
            }
            return null;
        }
    }
}
