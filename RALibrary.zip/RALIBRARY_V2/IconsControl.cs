﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;

namespace RALIBRARY_V2
{
    public class IconsControl
    {
        public void SetChecked(FontIcon element)
        {
            element.Glyph = "\uE8FB";
        }
        public void SetNotIcon(FontIcon element)
        {
            element.Glyph = "";
        }

        public void SetGoFullScreen(FontIcon element)
        {
            element.Glyph = "\uE1D8";
        }
        public void SetGoWindowScreen(FontIcon element)
        {
            element.Glyph = "\uE1D9";
        }


    }
}
