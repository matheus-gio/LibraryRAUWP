﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel.Core;
using Windows.Media.Core;
using Windows.Storage;
using Windows.Storage.FileProperties;
using Windows.UI.Core;
using Windows.UI.Xaml.Controls;

namespace RALIBRARY_V2
{
    public class VideoControl
    {
        public async Task<double> GetDurationVideoAsync(StorageFile vid)
        {
            VideoProperties videoProperties = await vid.Properties.GetVideoPropertiesAsync();
            TimeSpan duration = videoProperties.Duration;
            return duration.TotalMilliseconds;
        }
        public async void StartVideo(StorageFile vid, MediaElement mediaelement)
        {
            await CoreApplication.MainView.CoreWindow.Dispatcher.RunAsync(
            CoreDispatcherPriority.Normal, () =>
            {
                mediaelement.AutoPlay = true;
                mediaelement.SetPlaybackSource(MediaSource.CreateFromStorageFile(vid));
                mediaelement.Play();
            });
        }

    }
}
